### Release Version

### v1.0.0
1. Initial version of calculator, supporting multiple features such as 
a. addition
b. substraction
c. multiplication
d. division
e. cancel
f. exit
g. absolute
h. negative
i. square root
j. square
k. cubert
l. cube
m. repeat `n` last commands